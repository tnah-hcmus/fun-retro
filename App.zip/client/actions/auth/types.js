export const LOGIN = 'login';
export const LOGOUT = 'logout';
export const EDIT_NAME = 'edit_name';
