import { ADD_TASK, SET_TASK, REMOVE_TASK, UPDATE_TASK,  REMOVE_ALL_TASKS } from "./types";
import Axios from 'axios';

const _createID = () => {
  let gid = 'xyxxyx'.replace(/[xy]/g, (c) => {
  let r = Math.random() * 16 | 0,
  v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
  return gid;
}
//Delete all task
export const deleteAll = () => ({
    type: REMOVE_ALL_TASKS
});
/*export const deleteAllWServer = () => {
  return (dispatch, getState) => {
    const id = getState().auth.id;
    return database.deleteData({path}).then(() => {
      dispatch(deleteAll());
    })
  }
}*/

//Delete a task
export const deleteTask = (id, category) => ({
    type: REMOVE_TASK, 
    payload: {id, category}
  });
export const deleteTaskWServer = (id, category, boardId) => {
  return (dispatch, getState) => {
    const token = getState().auth.token;
    return Axios.post('/api/task/delete', {token, boardId, id})
    .then((res) => {
      dispatch(deleteTask(id));
    })
    .catch((e) => console.log(e));
  }
}

//Add a task
export const addTask = (task) => ({
  type: ADD_TASK, 
  payload: task
});
export const addTaskWServer = (task, boardId) => {

  return (dispatch, getState) => {
    task.owner = getState().auth.name || 'Người dùng ẩn danh';
    task.id = _createID();
    const token = getState().auth.token;
    return Axios.post('/api/task/add', {token, boardId, task})
          .then((res) => {
            dispatch(addTask(task));
          })
          .catch((e) => console.log(e));
  }
}
export const addFakeTask = (task) => {
  return (dispatch, getState) => {
    const owner = getState().auth.id;
    const id = Date.now();
    dispatch({
      type: ADD_TASK,
      payload: {
        ...task,
        owner,
        id
      }
    })
    
  }
}
//Update a task
export const updateTask = (id, newInfo) => {
  return {
      type: UPDATE_TASK,
      payload: {id: id, task: newInfo}
  };
}
export const updateTaskWServer = (id, boardId, newInfo) => {
  return (dispatch, getState) => {
    const token = getState().auth.token;
    return Axios.post('/api/task/update', {token, boardId, id, newTask: newInfo})
          .then((success) => {
            dispatch(updateTask(id, newInfo));
          })
          .catch((e) => console.log(e));
  }
}


//Init task
export const setTasks = (tasks) => ({
  type: SET_TASK, 
  payload: {tasks}
});

export const setTaskWServer = (boardId, newTaskList) => {
  return (dispatch, getState) => {
    const token = getState().auth.token;
    return Axios.post('/api/task/updateAll', {token, boardId, newTaskList})
          .then((success) => {
            dispatch(setTasks(newTaskList))
          })
          .catch((e) => console.log(e));
  }
}
export const startSetTasks = (boardId) => {
  return (dispatch, getState) => {
    const token = getState().auth.token;
    return Axios.post('/api/task/getByBoardId', {token, boardId})
          .then((res) => {
            console.log(res);
            dispatch(setTasks(res.data || []));
          })
          .catch((e) => {return new Error('Not your board')});
  }
}