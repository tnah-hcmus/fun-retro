export const ADD_TASK = 'add_task';
export const SET_TASK = 'set_task';
export const EDIT_TASK = 'edit_task';
export const REMOVE_TASK = 'remove_task';
export const REMOVE_ALL_TASKS = 'remove_all_tasks';
export const UPDATE_TASK = 'update_task';
export const REMOVE_ALL_TASKS_BY_CATEGORY = 'remove_by_cate';

