export const ADD_BOARD = 'add_board';
export const SET_BOARDS = 'set_boards';
export const DELETE_BOARD = 'remove_board';
export const UPDATE_BOARD = 'update_board';
export const PUBLIC_BOARD = 'public';
export const PRIVATE_BOARD = 'private';
